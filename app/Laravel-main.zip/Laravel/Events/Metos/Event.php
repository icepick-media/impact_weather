<?php 

namespace App\Laravel\Events\Metos;

abstract class Event {

	//

}