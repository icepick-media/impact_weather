<?php 

namespace App\Laravel\Events;

abstract class Event {

	//

}