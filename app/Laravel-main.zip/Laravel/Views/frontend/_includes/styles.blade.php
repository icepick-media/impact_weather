<!-- css file -->
<link rel="stylesheet" href="/frontend/css/bootstrap.min.css">
<link rel="stylesheet" href="http://fontawesome.io/assets/font-awesome/css/font-awesome.css">
<link rel="stylesheet" href="/frontend/css/style.css">
<link rel="stylesheet" href="/frontend/css/modif.css?v=1.20">
<!-- Responsive stylesheet -->
<link rel="stylesheet" href="/frontend/css/responsive.css">