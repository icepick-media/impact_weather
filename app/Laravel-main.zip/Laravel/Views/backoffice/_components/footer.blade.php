<footer class="footer footer-light">
  <p class="clearfix text-muted text-sm-center mb-0 px-2">
	  <span class="float-md-left d-xs-block d-md-inline-block">
	  	Copyright  &copy; {{ Carbon\Carbon::now()->format("Y") }} 
	  	<a href="#" target="_blank" class="text-bold-800 grey darken-2">{{ config('app.name') }} </a>, All rights reserved.
	  </span>
	  <span class="float-md-right d-xs-block d-md-inline-block">Hand-crafted &amp; Made with <i class="icon-heart5 pink"></i></span>
  </p>
</footer>