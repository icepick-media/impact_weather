<link rel="apple-touch-icon" sizes="60x60" href="/backoffice/robust-assets/ico/apple-icon-60.png">
<link rel="apple-touch-icon" sizes="76x76" href="/backoffice/robust-assets/ico/apple-icon-76.png">
<link rel="apple-touch-icon" sizes="120x120" href="/backoffice/robust-assets/ico/apple-icon-120.png">
<link rel="apple-touch-icon" sizes="152x152" href="/backoffice/robust-assets/ico/apple-icon-152.png">
<link rel="shortcut icon" type="image/x-icon" href="/backoffice/robust-assets/ico/favicon.ico">
<link rel="shortcut icon" type="image/png" href="/backoffice/robust-assets/ico/favicon-32.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-touch-fullscreen" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="default">