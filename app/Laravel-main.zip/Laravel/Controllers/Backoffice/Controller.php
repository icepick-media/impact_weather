<?php

namespace App\Laravel\Controllers\Backoffice;

use App\Laravel\Controllers\Controller as BaseController;
use Carbon;

class Controller extends BaseController
{
    
}
