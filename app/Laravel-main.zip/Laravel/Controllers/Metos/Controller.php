<?php

namespace App\Laravel\Controllers\Metos;

use App\Laravel\Controllers\Controller as BaseController;
use Carbon;

class Controller extends BaseController
{
    
}
