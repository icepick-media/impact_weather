<?php

namespace App\Laravel\Controllers;

use App\Http\Controllers\Controller as BaseController;

use App\Laravel\Services\ResponseManager;

class Controller extends BaseController
{
    
}
