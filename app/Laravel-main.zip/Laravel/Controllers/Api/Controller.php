<?php

namespace App\Laravel\Controllers\Api;

use App\Laravel\Controllers\Controller as BaseController;

class Controller extends BaseController
{
	
}
